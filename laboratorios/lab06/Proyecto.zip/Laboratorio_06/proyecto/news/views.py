from django.shortcuts import get_object_or_404, render
from .models import Category, NewsArticle


def home(request):
    articles = NewsArticle.objects.filter(is_published=True).select_related(
        "author", "category"
    )
    return render(request, "news/home.html", {"articles": articles})


def article_detail(request, article_id):
    article = get_object_or_404(
        NewsArticle.objects.select_related("author", "category"),
        pk=article_id, is_published=True,
    )
    return render(request, "news/detail.html", {"article": article})


def category_detail(request, slug):
    category = get_object_or_404(Category, slug=slug)
    articles = NewsArticle.objects.filter(
        category=category, is_published=True
    ).select_related("author", "category")
    return render(request, "news/category.html", {"category": category, "articles": articles})
