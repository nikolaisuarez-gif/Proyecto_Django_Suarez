from django.urls import path
from . import views

app_name = "news"
urlpatterns = [
    path("", views.home, name="home"),
    path("articles/<int:article_id>/", views.article_detail, name="article_detail"),
    path("category/<slug:slug>/", views.category_detail, name="category_detail"),
]
