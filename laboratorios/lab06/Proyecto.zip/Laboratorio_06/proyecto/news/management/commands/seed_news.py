from datetime import datetime, timedelta, timezone
from django.core.management.base import BaseCommand
from news.models import Author, Category, NewsArticle


class Command(BaseCommand):
    help = "Load six sample stories for the news portal."

    def handle(self, *args, **options):
        author, _ = Author.objects.get_or_create(
            name="Equipo Editorial", defaults={"bio": "Redacción del portal."}
        )
        categories = [
            Category.objects.get_or_create(name=name, slug=slug)[0]
            for name, slug in [("Tecnología", "tecnologia"), ("Cultura", "cultura"), ("Ciudad", "ciudad")]
        ]
        stories = [
            ("La ciudad impulsa nuevos espacios verdes", "Un plan urbano prioriza parques de barrio.", "ciudad"),
            ("Jóvenes crean una biblioteca comunitaria", "La iniciativa conecta voluntarios y lectores.", "cultura"),
            ("Herramientas digitales para aprender mejor", "Docentes prueban recursos abiertos en clase.", "tecnologia"),
            ("Un festival acerca el arte a los vecinos", "La programación incluye talleres gratuitos.", "cultura"),
            ("Emprendimientos locales llegan a internet", "Pequeños negocios fortalecen sus canales digitales.", "tecnologia"),
            ("Nueva ruta facilita el transporte público", "El recorrido conecta zonas residenciales.", "ciudad"),
        ]
        for index, (title, summary, slug) in enumerate(stories):
            NewsArticle.objects.update_or_create(
                title=title,
                defaults={
                    "summary": summary, "body": f"{summary} Esta nota presenta los detalles y el contexto de la iniciativa.",
                    "author": author, "category": next(c for c in categories if c.slug == slug),
                    "published_at": datetime.now(timezone.utc) - timedelta(days=index),
                    "is_published": True,
                    "image_url": f"https://picsum.photos/seed/noticia{index + 1}/900/540",
                },
            )
        self.stdout.write(self.style.SUCCESS("Se cargaron seis noticias de ejemplo."))
