from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse
from .models import NewsArticle


class NewsPortalTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_news", verbosity=0)

    def test_seed_creates_six_published_articles(self):
        self.assertEqual(NewsArticle.objects.filter(is_published=True).count(), 6)

    def test_home_shows_shared_header_and_articles(self):
        response = self.client.get(reverse("news:home"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "PUNTO DIARIO")
        self.assertContains(response, "La ciudad impulsa nuevos espacios verdes")

    def test_detail_and_category_pages_render(self):
        article = NewsArticle.objects.first()
        detail = self.client.get(reverse("news:article_detail", args=[article.pk]))
        category = self.client.get(reverse("news:category_detail", args=[article.category.slug]))
        self.assertContains(detail, article.title)
        self.assertContains(category, article.category.name)

    def test_unpublished_article_is_not_public(self):
        article = NewsArticle.objects.first()
        article.is_published = False
        article.save(update_fields=["is_published"])
        self.assertEqual(self.client.get(reverse("news:article_detail", args=[article.pk])).status_code, 404)
