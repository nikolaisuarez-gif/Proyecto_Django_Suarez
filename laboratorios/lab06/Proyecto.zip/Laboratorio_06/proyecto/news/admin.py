from django.contrib import admin
from .models import Author, Category, NewsArticle


@admin.register(NewsArticle)
class NewsArticleAdmin(admin.ModelAdmin):
    list_display = ("title", "author", "category", "published_at", "is_published")
    list_filter = ("category", "is_published", "published_at")
    search_fields = ("title", "summary", "body", "author__name")
    date_hierarchy = "published_at"


admin.site.register(Author)
admin.site.register(Category)
