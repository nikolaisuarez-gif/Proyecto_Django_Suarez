# Laboratorio 6 Motor de plantillas con Django

Portal de noticias pequeño para practicar plantillas heredadas, bloques, fragmentos reutilizables, rutas con nombre, filtros de fecha e imágenes y el panel de administración. La portada, la página de noticia y la sección por categoría comparten `news/base.html`; las tarjetas se reutilizan desde `_article_card.html`.

## Puesta en marcha

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_news
python manage.py runserver
```

Abre `http://127.0.0.1:8000/`. Para administrar noticias, crea una cuenta con `python manage.py createsuperuser` y visita `/admin/`.

## Estructura

- `news/models.py`: autor, categoría y noticia con imagen, fecha y estado.
- `news/templates/news/base.html`: encabezado, navegación y bloques compartidos.
- `news/templates/news/_article_card.html`: tarjeta reutilizable.
- `news/templates/news/home.html`, `detail.html` y `category.html`: tres vistas del portal.
- `news/management/commands/seed_news.py`: carga seis noticias de muestra.

Las imágenes de muestra usan URLs públicas y se presentan en escala de grises. Para un uso sin conexión, reemplaza `image_url` por archivos locales.
