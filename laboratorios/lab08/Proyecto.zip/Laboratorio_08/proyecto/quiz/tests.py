from rest_framework import status
from rest_framework.test import APITestCase
from .models import Exam, Question, Option


class QuizApiTests(APITestCase):
    def setUp(self):
        self.exam = Exam.objects.create(title="Evaluación de prueba")
        self.question = Question.objects.create(exam=self.exam, text="¿Cuánto es 2 + 2?", position=1)
        self.question.options.create(text="4", is_correct=True)
        self.question.options.create(text="5", is_correct=False)

    def test_exam_crud_and_pagination_envelope(self):
        response = self.client.get("/api/exams/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("results", response.data)
        created = self.client.post("/api/exams/", {"title": "Nuevo examen", "description": "Prueba"}, format="json")
        self.assertEqual(created.status_code, status.HTTP_201_CREATED, created.data)
        detail = self.client.get(f"/api/exams/{created.data['id']}/")
        self.assertEqual(detail.status_code, status.HTTP_200_OK)
        patched = self.client.patch(f"/api/exams/{created.data['id']}/", {"title": "Actualizado"}, format="json")
        self.assertEqual(patched.status_code, status.HTTP_200_OK)
        deleted = self.client.delete(f"/api/exams/{created.data['id']}/")
        self.assertEqual(deleted.status_code, status.HTTP_204_NO_CONTENT)

    def test_question_nested_options_and_exam_filter_search(self):
        response = self.client.get("/api/questions/?exam=1&search=2%20%2B%202")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["results"][0]["options"][0]["text"], "4")
        created = self.client.post("/api/questions/", {
            "exam": self.exam.id, "text": "Capital del Perú", "position": 2,
            "options": [{"text": "Lima", "is_correct": True}, {"text": "Cusco", "is_correct": False}],
        }, format="json")
        self.assertEqual(created.status_code, status.HTTP_201_CREATED, created.data)
        self.assertEqual(len(created.data["options"]), 2)

    def test_question_rejects_zero_or_multiple_correct_options(self):
        for options in [
            [{"text": "A", "is_correct": False}],
            [{"text": "A", "is_correct": True}, {"text": "B", "is_correct": True}],
        ]:
            response = self.client.post("/api/questions/", {
                "exam": self.exam.id, "text": "Pregunta inválida", "position": 3, "options": options,
            }, format="json")
            self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_option_resource_supports_http_crud(self):
        option = self.question.options.first()
        response = self.client.get("/api/options/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        created = self.client.post("/api/options/", {"question": self.question.id, "text": "6", "is_correct": False}, format="json")
        self.assertEqual(created.status_code, status.HTTP_201_CREATED)
        patched = self.client.patch(f"/api/options/{created.data['id']}/", {"text": "7"}, format="json")
        self.assertEqual(patched.status_code, status.HTTP_200_OK)
        deleted = self.client.delete(f"/api/options/{created.data['id']}/")
        self.assertEqual(deleted.status_code, status.HTTP_204_NO_CONTENT)
        self.assertTrue(Option.objects.filter(pk=option.pk).exists())
