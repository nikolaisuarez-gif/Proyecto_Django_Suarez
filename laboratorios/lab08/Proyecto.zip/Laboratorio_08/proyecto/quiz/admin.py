from django.contrib import admin
from .models import Exam, Option, Question


class OptionInline(admin.TabularInline):
    model = Option
    extra = 2


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ("text", "exam", "position")
    inlines = [OptionInline]


admin.site.register(Exam)
admin.site.register(Option)
