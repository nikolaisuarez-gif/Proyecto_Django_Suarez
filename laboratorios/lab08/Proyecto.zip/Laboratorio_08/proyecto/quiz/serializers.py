from django.db import transaction
from rest_framework import serializers
from .models import Exam, Option, Question


class OptionSerializer(serializers.ModelSerializer):
    question = serializers.PrimaryKeyRelatedField(queryset=Question.objects.all())

    class Meta:
        model = Option
        fields = ["id", "question", "text", "is_correct"]
        read_only_fields = ["id"]


class NestedOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Option
        fields = ["id", "text", "is_correct"]
        read_only_fields = ["id"]


class QuestionSerializer(serializers.ModelSerializer):
    options = NestedOptionSerializer(many=True)
    exam = serializers.PrimaryKeyRelatedField(queryset=Exam.objects.all())

    class Meta:
        model = Question
        fields = ["id", "exam", "text", "position", "options"]
        read_only_fields = ["id"]

    def validate_options(self, options):
        if len([option for option in options if option.get("is_correct", False)]) != 1:
            raise serializers.ValidationError("La pregunta debe tener exactamente una opción correcta.")
        return options

    @transaction.atomic
    def create(self, validated_data):
        options_data = validated_data.pop("options")
        question = Question.objects.create(**validated_data)
        Option.objects.bulk_create([Option(question=question, **item) for item in options_data])
        return question

    @transaction.atomic
    def update(self, instance, validated_data):
        options_data = validated_data.pop("options", None)
        for key, value in validated_data.items():
            setattr(instance, key, value)
        instance.save()
        if options_data is not None:
            instance.options.all().delete()
            Option.objects.bulk_create([Option(question=instance, **item) for item in options_data])
        return instance


class ExamSerializer(serializers.ModelSerializer):
    questions = QuestionSerializer(many=True, read_only=True)

    class Meta:
        model = Exam
        fields = ["id", "title", "description", "created_at", "questions"]
        read_only_fields = ["id", "created_at", "questions"]
