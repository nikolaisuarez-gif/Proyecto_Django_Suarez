from rest_framework import filters, viewsets
from .models import Exam, Option, Question
from .serializers import ExamSerializer, OptionSerializer, QuestionSerializer


class ExamViewSet(viewsets.ModelViewSet):
    queryset = Exam.objects.all().order_by("id")
    serializer_class = ExamSerializer


class QuestionViewSet(viewsets.ModelViewSet):
    serializer_class = QuestionSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ["text"]

    def get_queryset(self):
        queryset = Question.objects.prefetch_related("options").select_related("exam").order_by("position", "id")
        exam_id = self.request.query_params.get("exam")
        if exam_id:
            queryset = queryset.filter(exam_id=exam_id)
        return queryset


class OptionViewSet(viewsets.ModelViewSet):
    queryset = Option.objects.select_related("question").order_by("id")
    serializer_class = OptionSerializer
