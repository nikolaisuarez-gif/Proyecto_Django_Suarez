# Laboratorio 8 Servicios web con Django REST Framework

API para administrar exámenes, preguntas y opciones. Los recursos se publican con `ModelSerializer`, `ModelViewSet` y un enrutador. Las preguntas reciben sus opciones anidadas y se validan para que exista exactamente una respuesta correcta. El examen se representa en una pregunta mediante su identificador.

## Puesta en marcha

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

La API navegable está en `http://127.0.0.1:8000/api/`. Para ejecutar las pruebas: `python manage.py test`.

## Recursos

| Recurso | Dirección | Métodos principales | Relaciones |
| --- | --- | --- | --- |
| Exámenes | `/api/exams/` | GET, POST; detalle con GET, PUT, PATCH, DELETE | Las preguntas aparecen en el examen |
| Preguntas | `/api/questions/` | GET, POST; detalle con GET, PUT, PATCH, DELETE | `exam` se envía como ID; `options` va anidado |
| Opciones | `/api/options/` | GET, POST; detalle con GET, PUT, PATCH, DELETE | `question` se envía como ID |

El listado de preguntas acepta `?exam=1` y `?search=texto`. La paginación usa diez resultados por página y el formato `count`, `next`, `previous` y `results`. El permiso inicial es `AllowAny`, como en la guía; antes de publicar el servicio se debe sustituir por autenticación y permisos apropiados.

## Ejemplo de pregunta

```json
{
  "exam": 1,
  "text": "¿Cuánto es 2 + 2?",
  "position": 1,
  "options": [
    {"text": "4", "is_correct": true},
    {"text": "5", "is_correct": false}
  ]
}
```

Una pregunta sin exactamente una opción correcta devuelve HTTP 400 con un mensaje de validación.
